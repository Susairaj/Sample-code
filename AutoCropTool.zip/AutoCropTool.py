# AUTOCROP TOOL --------#
# copy as is in menu.py

def autocroptool():
	selectedNodes = nuke.selectedNodes()
	for eachNode in selectedNodes:
		# if it's a read node proceed, if not move on to the next selected node
		if eachNode.Class() == "Read":
			# create curveTool node
			curveNode = nuke.nodes.CurveTool()
			# set input 0 to eachNode (a Read node in this case)
			curveNode.setInput(0, eachNode)
			# set the operation to Auto Crop
			curveNode.knob("operation").setValue("Auto Crop")
			# set the ROI to the width and height coming from the Read node
			curveNode["ROI"].setValue([0, 0, eachNode.width(), eachNode.height()])
			# execute Go! button using the project's frame range
			nuke.execute(curveNode, nuke.root().firstFrame(), nuke.root().lastFrame())   #<-- takes project's frame range
			#nuke.execute(curveNode, eachNode.knob("first").value(), eachNode.knob("last").value())    #<-- inherits the range from the read node
			# create crop node
			cropNode = nuke.nodes.Crop()
			# set input 0 to curveNode        
			cropNode.setInput(0, curveNode)
			# copy animation from curveTool node
			cropNode.knob("box").copyAnimations(curveNode.knob("autocropdata").animations())
			# set blackoutside to False, otherwise objects can come out with an ugly black outline
			cropNode.knob("crop").setValue(False)    

autocroptoolMenu = nuke.menu("Nodes").addMenu("AutoCropTool", icon="AutoCropTool.png")
autocroptoolMenu.addCommand("AutoCropTool", "autocroptool()")
# AUTOCROP TOOL --------#