__all__ = ['Report']


class Report(object):
    
    def __init__(self, request):
        self.request = request
