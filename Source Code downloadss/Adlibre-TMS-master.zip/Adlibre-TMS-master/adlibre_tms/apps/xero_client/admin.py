from django.contrib import admin

from xero_client.models import XeroInvoice

admin.site.register(XeroInvoice)