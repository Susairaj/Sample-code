<script type="text/javascript">

$(document).ready(function(){
    setTimeout(function(){
        $('.messages').fadeOut('slow');
    }, 1000);
});
</script>
