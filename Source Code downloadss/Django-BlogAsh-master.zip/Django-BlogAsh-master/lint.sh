pep8 --ignore E501 --exclude=migrations sampleblog blog

pylint --rcfile=.pylintrc sampleblog blog