from django.contrib import admin
from common.models import Comment


admin.site.register(Comment)
