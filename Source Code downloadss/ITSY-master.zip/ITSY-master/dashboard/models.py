from django.db import models


#todo
class Dashboard(models.Model):
    pass


#todo
class Timeline(models.Model):
    pass
