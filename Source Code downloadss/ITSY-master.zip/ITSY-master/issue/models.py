import pickle
import datetime
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.core.exceptions import ValidationError
from django.db.models.signals import post_save,pre_delete
from dictdiffer import diff as ddiff
from django.forms.models import model_to_dict
from autoslug import AutoSlugField
from south.modelsinspector import add_introspection_rules
from account.models import Account
from common.models import Comment,IssueFieldName
from common.fields import ListField
from common.utils import update_field_name,delete_field_name
from project.models import ProjectVersion, Project


class IssueType(models.Model):
    name = models.CharField(_(u'Type Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueType)
pre_delete.connect(receiver=delete_field_name, sender=IssueType)


class IssuePriority(models.Model):
    name = models.CharField(_(u'Issue Priority'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True,editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssuePriority)
pre_delete.connect(receiver=delete_field_name, sender=IssuePriority)


class IssueCharField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueCharField)
pre_delete.connect(receiver=delete_field_name, sender=IssueCharField)


class IssueTextField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueTextField)
pre_delete.connect(receiver=delete_field_name, sender=IssueTextField)


class IssueImageField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueImageField)
pre_delete.connect(receiver=delete_field_name, sender=IssueImageField)


class IssueFileField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueFileField)
pre_delete.connect(receiver=delete_field_name, sender=IssueFileField)


class IssueBooleanField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueBooleanField)
pre_delete.connect(receiver=delete_field_name, sender=IssueBooleanField)


class IssueDatetimeField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueDatetimeField)
pre_delete.connect(receiver=delete_field_name, sender=IssueDatetimeField)


class IssueChoiceField(models.Model):
    name = models.CharField(_(u'Field Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    choices = models.TextField(_(u'Choices'),help_text=_(u'Use comma separated values ie: 1,2,3,4'))
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self,*args, **kwargs):
        super(IssueChoiceField, self).clean(*args, **kwargs)
        if self.name and self.choices:
            if IssueFieldName.objects.filter(name=self.name).exists():
                if not self.pk:
                    raise ValidationError(_(u'There is another (type of) field with this name'))
                else:
                    if not self.name == self._prev_name:
                        if IssueFieldName.objects.filter(name=self.name).exists():
                            raise ValidationError(_(u'There is another (type of) field with this name'))
                    IssueFieldName.objects.filter(name=self.name).delete()
            choice_arr = []
            try:
                choice_arr = self.choices.split(',')
                for c in choice_arr:
                    if not len(c) > 0:
                        raise ValidationError(_(u'Use one comma for each item ie: home,tree,car,4'))
            except:
                raise ValidationError(_(u'Choices should be in format: 1,2,3,4,5,6'))
        else:
            raise ValidationError(_(u'This fields are required'))


post_save.connect(receiver=update_field_name, sender=IssueChoiceField)
pre_delete.connect(receiver=delete_field_name, sender=IssueChoiceField)


class IssuePerson(models.Model):
    name = models.CharField(_(u'Role Name'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    required = models.BooleanField(_(u'Is Required?'), default=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssuePerson)
pre_delete.connect(receiver=delete_field_name, sender=IssuePerson)


class IssueStatus(models.Model):
    name = models.CharField(_(u'Status'), max_length=128,unique=True)
    _prev_name = models.CharField(max_length=128,editable=False, null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True, editable=False)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name

    def clean(self):
        if IssueFieldName.objects.filter(name=self.name).exists():
            if not self.pk:
                raise ValidationError(_(u'There is another (type of) field with this name'))
            else:
                if not self.name == self._prev_name:
                    if IssueFieldName.objects.filter(name=self.name).exists():
                        raise ValidationError(_(u'There is another (type of) field with this name'))
                IssueFieldName.objects.filter(name=self.name).delete()


post_save.connect(receiver=update_field_name, sender=IssueStatus)
pre_delete.connect(receiver=delete_field_name, sender=IssueStatus)

add_introspection_rules([], ["^issue\.models\.ListField"])


class IssueFlow(models.Model):
    name = models.CharField(_(u'Flow Name'), max_length=128,unique=True)
    accounts = ListField(_(u'Accounts List'), null=True, blank=True)
    current = models.PositiveIntegerField(_(u'Current'), null=True, blank=True)
    next = models.PositiveIntegerField(_(u'Next'), null=True, blank=True)
    prev = models.PositiveIntegerField(_(u'Previous'), null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name


class IssueTemplate(models.Model):
    name = models.CharField(_(u'Template Name'),unique=True, max_length=128,help_text=_(u'Give a name to your template for easy access'))
    char_fields = models.ManyToManyField(IssueCharField, verbose_name=_(u'Char Fields'), null=True, blank=True)
    text_fields = models.ManyToManyField(IssueTextField, verbose_name=_(u'Text Fields'), null=True, blank=True)
    image_fields = models.ManyToManyField(IssueImageField, verbose_name=_(u'Image Fields'), null=True, blank=True)
    file_fields = models.ManyToManyField(IssueFileField, verbose_name=_(u'File Fields'),null=True, blank=True)
    bool_fields = models.ManyToManyField(IssueBooleanField,verbose_name=_(u'Boolean Fields'), null=True, blank=True)
    choice_fields = models.ManyToManyField(IssueChoiceField,verbose_name=_(u'Choice Fields'), null=True, blank=True)
    date_fields = models.ManyToManyField(IssueDatetimeField,verbose_name=_(u'Datetime Fields'),null=True,blank=True)
    people = models.ManyToManyField(IssuePerson, verbose_name=_(u'People'), null=True, blank=True )
    project = models.ForeignKey(Project,verbose_name=_(u'Project'))
    flow = models.ForeignKey(IssueFlow, verbose_name=_(u'Issue Flow'), null=True,blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.name


class Issue(models.Model):
    title = models.CharField(_(u'Title'), max_length=255,unique=True, db_index=True)
    slug = AutoSlugField(populate_from='title', unique=True,editable=False)
    summary = models.TextField(_(u'Summary'), null=True, blank=True)
    effort_estimated = models.CharField(_(u'Estimated Effort'),max_length=128, null=True, blank=True)
    effort_remaining = models.CharField(_(u'Remaining Effort'),max_length=128, null=True, blank=True)
    effort_calc = models.PositiveIntegerField(_(u'Effort Calculated'), null=True, blank=True,editable=False)
    project_version = models.ForeignKey(ProjectVersion,verbose_name=_(u'Project Version'))
    assignee = models.ForeignKey(Account, verbose_name=_(u'Assignee'), null=True, blank=True)
    reporter = models.PositiveIntegerField(_(u'Reporter'),editable=False,null=True,blank=True)
    type = models.ForeignKey(IssueType, verbose_name=_(u'Type'), null=True, blank=True)
    status = models.ForeignKey(IssueStatus,verbose_name=_(u'Status'), null=True, blank=True)
    priority = models.ForeignKey(IssuePriority, verbose_name=_(u'Priority'), null=True, blank=True)
    template = models.ForeignKey(IssueTemplate, verbose_name=_(u'Issue Template'),help_text=_(u'Provide a template even it is empty'))
    sub_issues = models.ManyToManyField('self', symmetrical=False,null=True, blank=True)
    changelog = models.TextField(editable=False, null=True, blank=True)
    is_draft = models.BooleanField(_(u'Draft'), default=True)
    resolved = models.BooleanField(_(u'Resolved'), default=False)
    closed = models.BooleanField(_(u'Closed'), default=False)
    end_date =  models.DateTimeField(_(u'End Date'), null=True, blank=True)
    due_date = models.DateTimeField(_(u'Due Date'), null=True, blank=True)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True)
    update_date = models.DateTimeField(_(u'Update Date'), auto_now=True)

    class Meta:
        ordering = ['-entry_date']
        app_label = 'issue'

    def __unicode__(self):
        return self.title

    def overdue_status(self):
        if datetime.date.today() > self.due_date :
            return True
        else:
            return False

    def get_edit_link(self):
        return '<a href="/issue/view/details/%s/"><b>%s</b></a>' % (self.slug,self.title)


class IssueWatch(models.Model):
    issue = models.ForeignKey(Issue, verbose_name=_(u'Issue'))
    watchers = models.ManyToManyField(Account, verbose_name=_(u'Watchers'))

    class Meta:
        app_label = 'issue'


class IssueComment(models.Model):
    models.ForeignKey(Issue, verbose_name=_(u'Issue'))
    models.ManyToManyField(Comment, verbose_name=_(u'Comments'))

    class Meta:
        app_label = 'issue'


class IssueCharValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueCharField)
    value = models.CharField(_(u'Field Value'), max_length=255,null=True,blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssueTextValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueTextField)
    value = models.TextField(_(u'Field Value'), null=True, blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssueImageValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueImageField)
    value = models.ImageField(_(u'Image'), upload_to='Issue Images', null=True, blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssueFileValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueFileField)
    value = models.ImageField(_(u'File'), upload_to='Issue Files', null=True, blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssuePersonValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssuePerson)
    value = models.ForeignKey(Account, null=True, blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssueBoolValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueBooleanField)
    value = models.BooleanField(_(u'Field Value'), default=False)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class IssueDateValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueDatetimeField)
    value = models.DateTimeField(_(u'Field Value'),null=True,blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")

class IssueChoiceValue(models.Model):
    issue = models.ForeignKey(Issue)
    field = models.ForeignKey(IssueChoiceField)
    value = models.CharField(_(u'Field Value'),max_length=255, null=True, blank=True)

    class Meta:
        app_label = 'issue'
        unique_together = ("issue", "field")


class History(models.Model):
    issue = models.ForeignKey(Issue, null=True, blank=True,editable=False)
    account = models.ForeignKey(Account,editable=False)
    log = models.TextField(_(u'Log'), editable=False)
    entry_date = models.DateTimeField(_(u'Create Date'), auto_now_add=True,editable=False)

    class Meta:
        app_label = 'issue'


FIELDS = '__fields__'


def set_issue_changes(issue):
    model_as_dict = model_to_dict(issue)
    model_as_dict['__fields__'] = {}
    template_id = model_as_dict.get('template',None)
    if template_id:
        template = IssueTemplate.objects.get(pk=template_id)

        #uniqueness of item.name is guaranteed
        for item in template.char_fields.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueCharValue.objects.get(
                    issue=issue,
                    field=item
                ).value

        for item in template.text_fields.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueTextValue.objects.get(
                    issue=issue,
                    field=item
                ).value

        for item in template.bool_fields.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueTextValue.objects.get(
                    issue=issue,
                    field=item
                ).value

        for item in template.choice_fields.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueTextValue.objects.get(
                    issue=issue,
                    field=item
                ).value

        for item in template.date_fields.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueTextValue.objects.get(
                    issue=issue,
                    field=item
                ).value

        for item in template.people.all():
            model_as_dict[FIELDS][ '%s' % item.name ] =\
                IssueTextValue.objects.get(
                    issue=issue,
                    field=item
                ).value
    # print "#######################"
    # print model_as_dict
    # print "#######################"
    # prev_model_as_dict = {}
    # if issue.changelog:
    #     prev_model_as_dict = pickle.loads(issue.changelog)
    # _diff = ddiff(prev_model_as_dict, model_as_dict)
    # print "#######################"
    # #print dict((y, z[1]) for (x, y, z) in list(_diff))
    # print list(_diff)
    # print "#######################"
    # #issue.changelog = pickle.dumps(model_as_dict)
    # #issue.save()