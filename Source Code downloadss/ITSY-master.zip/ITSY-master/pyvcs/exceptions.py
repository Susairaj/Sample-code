class CommitDoesNotExist(Exception):
    pass

class FileDoesNotExist(Exception):
    pass

class FolderDoesNotExist(Exception):
    pass
