from django.contrib import admin

from repos.models import CodeRepository


admin.site.register(CodeRepository)
