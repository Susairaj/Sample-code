
{
    'name': 'KnowSpace Document Management',
    'version': '1.1',
    'author': 'Brand Equity Solutions',
    'website': 'www.besplatform.com',
    'summary': 'Manage various type of KnowSpace documents',
    'description': """
            Element Document Management
    """,
    'depends': ['base', 'mail', 'knowledge', 'web_tree_image', 'document'],
    'category': 'Document Management',
    'sequence': 16,
    'data': [
        'views/knowspace_docs_view.xml',
        "views/knowspace_docs.xml",
        'security/knowspace_security.xml',
        'security/ir.model.access.csv',
    ],
    'css': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
