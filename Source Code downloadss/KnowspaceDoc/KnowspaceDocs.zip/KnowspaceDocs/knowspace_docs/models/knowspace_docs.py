from openerp.osv import fields, osv
from openerp.tools.translate import _
import datetime

class ir_attachment(osv.osv):
    _inherit = 'ir.attachment'
    _order = "name asc"


    ''' To show file extension icon - Sathish '''
    def _get_file_extension(self, cr, uid, ids, name, arg, context=None):
        res = {}; extension = '';
        for record in self.browse(cr, uid, ids):
            icon = ''
            if record.datas:
                filename = record.datas_fname
                if filename:
                    extension  = filename.split('.')
                    if extension[1].strip() in ('xlsx','xls','csv','XLSX','XLS','CSV'):
                        icon = 'knowspace_docs/static/src/img/excel.png'
                    elif extension[1].strip() in ('txt','TXT'):
                        icon = 'knowspace_docs/static/src/img/text.png'
                    elif extension[1].strip() == 'docx':
                        icon = 'knowspace_docs/static/src/img/word.png'
                    elif extension[1].strip() in ('pdf', 'PDF'):
                        icon = 'knowspace_docs/static/src/img/pdf.png'
                    elif extension[1].strip() in ('png', 'jpeg', 'gif', 'jpg', 'JPG', 'PNG', 'GIF'):
                        icon = 'knowspace_docs/static/src/img/image.png'
                    elif extension[1].strip() == 'pptx':
                        icon = 'knowspace_docs/static/src/img/ppt.png'
                    elif extension[1].strip()  in ('flv','mp4','mpeg','mkv','webm','wmv','3gp'):
                        icon = 'knowspace_docs/static/src/img/video.png'
                    elif extension[1].strip()  in ('mp3','MP3'):
                        icon = 'knowspace_docs/static/src/img/audio.png'
                    else:
                        icon = 'knowspace_docs/static/src/img/other.png'
            else:
                if record.type == 'url':
                    icon = 'knowspace_docs/static/src/img/url.png'
            res[record.id] = icon
        return res

    ''' Update access rights based on the selected directory '''
    def _update_access_rights(self, cr, uid, ids, name, arg, context=None):
        groups_id = []; file_rights_obj = self.pool.get('file.rights');is_read = False; is_upload = False; is_comment = False; res = {}
        for record in self.browse(cr, uid, ids):
            for file in file_rights_obj.browse(cr, uid,file_rights_obj.search(cr, uid, [('ir_attachment_id', '=', ids)], context=context)):
                groups_id.append(file.res_group_id)
            for res_group in self.pool.get('res.users').read(cr, uid, [uid], ['groups_id'], context=context)[0]['groups_id']:
                if res_group in groups_id:
                    for group in file_rights_obj.browse(cr, uid,file_rights_obj.search(cr, uid, [('ir_attachment_id', '=', ids[0]),('res_group_id', '=', res_group)])):
                        if group.is_read == True:
                            is_read = True
                        if group.is_upload == True:
                            is_upload = True
                        if group.is_comment == True:
                            is_comment = True
        res[record.id] = {
                'is_read': is_read,
                'is_upload': is_upload,
                'is_comment': is_comment,
            }
        return res


    def _is_reviewer(self, cr, uid, ids, field_name, arg, context):
        res = {}
        for req in self.browse(cr, uid, ids, context=context):
            if req.review_by_id.id:
                partner_id = req.review_by_id.id
                res_usr_id = self.pool.get('res.users').search(cr,uid, [('partner_id', '=' , partner_id)], context=context)
                if res_usr_id[0] == uid or uid == 1:
                    res[req.id] = True
                else:
                    res[req.id] = False
        return res

    def unlink(self, cr, uid, ids, context=None):
        for record in self.browse(cr, uid, ids):
            if uid == record.user_id.id or uid == 1:
                if isinstance(ids, (int, long)):
                    ids = [ids]
                self.check(cr, uid, ids, 'unlink', context=context)
                # First delete in the database, *then* in the filesystem if the
                # database allowed it. Helps avoid errors when concurrent transactions
                # are deleting the same file, and some of the transactions are
                # rolled back by PostgreSQL (due to concurrent updates detection).
                to_delete = [a.store_fname
                                for a in self.browse(cr, uid, ids, context=context)
                                    if a.store_fname]
                res = super(ir_attachment, self).unlink(cr, uid, ids, context)
                for file_path in to_delete:
                    self._file_delete(cr, uid, file_path)
                return res
            else:
                raise osv.except_osv(_('Warning !'),_('You can not delete others record.'))
            return True


    _columns = {
        'name' :fields.char('Title', required=True, track_visibility='onchange'),
        'state':fields.selection([('draft', 'Draft'), ('request_review', 'Waiting for Review'), ('in_review', 'In Review'), ('rejected', 'Rejected'), ('approved',  'Approved'), ('published',  'Published')], 'State'),
        'url':fields.char('URL', size=2500),
        'file_icon':fields.function(_get_file_extension, type="char", string="Icons"),
        'is_file_content':fields.boolean('File'),
        'is_directory':fields.boolean('Directory Available'),
        'is_file_extension':fields.char('File Exetension'),
        'tags':fields.char('Tags'),
        'keywords':fields.char('Keywords'),
        'author1':fields.many2one('author.author','Author 1'),
        'author2':fields.many2one('author.author','Author 2'),
        'author3':fields.many2one('author.author','Author 3'),
        'is_active':fields.boolean('Active?'),
        'review_by_id' : fields.many2one('res.partner', 'Review By'),
        'is_read': fields.function(_update_access_rights, type="boolean", string="Read?", multi="access_rights"),
        'is_upload': fields.function(_update_access_rights, type="boolean", string="Upload?", multi="access_rights"),
        'is_comment': fields.function(_update_access_rights, type="boolean", string="Comment?", multi="access_rights"),
        'is_review_id': fields.function(_is_reviewer, type="boolean", string="Reviewer?"),
        'comment' : fields.text('Reject/Approve Comment')
    }

    _defaults = {
       'state': lambda *a: 'draft',
       'is_file_content':False,
       'is_directory':False,
       'is_active':True
    }

    def create(self, cr, uid, vals, context=None):
        extension = ''
        if '/web' in vals.get('name'):
            vals.update({'is_file_content': True})
        if vals.get('type') == 'binary' and not vals.get('datas'):
            raise osv.except_osv(_('File Error'), _('Please Select File to Upload...!'))
        if vals.get('type') == 'url' and not vals.get('url'):
            raise osv.except_osv(_('File Error'), _('URL is Empty...!'))
        if vals.get('parent_id'):
            vals.update({'is_directory': True})
        if vals.get('datas_fname'):
            extension  = vals.get('datas_fname').split('.')
            if extension[1].strip() in ('png', 'jpeg', 'gif', 'jpg', 'JPG', 'PNG', 'GIF'):
                vals.update({'is_file_extension': 'Images'})
            elif extension[1].strip() in ('docx', 'pdf','txt'):
                vals.update({'is_file_extension': 'Documents'})
            elif extension[1].strip()  in ('xlsx','xls'):
                vals.update({'is_file_extension': 'Excel Documents'})
            elif extension[1].strip()  in ('flv','mp4','mpeg','mkv','webm','wmv'):
                    vals.update({'is_file_extension': 'Videos'})
            else:
                vals.update({'is_file_extension': 'Others'})
        if vals.get('datas_fname'):
            extension  = vals.get('datas_fname').split('.')
            if extension[1].strip() == 'exe':
                raise osv.except_osv(_('File Error'), _('This is an execution file can not be attached...!'))
        if vals.get('review_by_id'):
            sender = self.pool.get('res.users').browse(cr, uid, uid).partner_id
            vals.update({'state':'request_review'})
        return super(ir_attachment, self).create(cr, uid, vals, context=context)


    def write(self, cr, uid, ids, vals, context=None):
        extension = ''
        for record in self.browse(cr, uid, ids):
            if '/web' in record.name:
                vals.update({'is_file_content': True})
            if record.parent_id:
                vals.update({'is_directory': True})
            if vals.get('datas_fname'):
                extension  = vals.get('datas_fname').split('.')
                print extension[1].strip()
                if extension[1].strip() in ('png', 'jpeg', 'gif', 'jpg', 'JPEG','JPG', 'PNG', 'GIF'):
                    vals.update({'is_file_extension': 'Images'})
                elif extension[1].strip() in ('docx', 'pdf','txt'):
                    vals.update({'is_file_extension': 'Documents'})
                elif extension[1].strip()  in ('xlsx','xls'):
                    vals.update({'is_file_extension': 'Excel Documents'})
                elif extension[1].strip()  in ('flv','mp4','mpeg','mkv','webm','wmv'):
                    vals.update({'is_file_extension': 'Videos'})
            if record.datas_fname:
                extension  = record.datas_fname.split('.')
                if extension[1].strip() == 'exe':
                    raise osv.except_osv(_('File Error'), _('This is an execution file can not be attached...!'))
        return super(ir_attachment, self).write(cr, uid, ids, vals, context=context)

    def action_inreview(self, cr, uid, ids, context=None):
        for record in self.browse(cr, uid, ids):
            self.write(cr, uid, ids, {'state': 'in_review' })
        return True

    def action_published(self, cr, uid, ids, context=None):
        for record in self.browse(cr, uid, ids):
            self.write(cr, uid, ids, {'state': 'published' })
        return True
    ''' To change state from in review to in reject - Sathish '''
    def action_reject(self, cr, uid, ids, context=None):
        for record in self.browse(cr, uid, ids):
            self.write(cr, uid, ids, {'state': 'rejected' })
        return True


    ''' To change state from in review to approved - Sathish '''
    def action_approve(self, cr, uid, ids, context=None):
        for record in self.browse(cr, uid, ids):
            self.write(cr, uid, ids, {'state': 'approved' })
        return True



class file_rights(osv.osv):
    _name = 'file.rights'
    _description = 'File access rights'

    _columns = {
        'ir_attachment_id' : fields.many2one('ir.attachment', 'Attachment'),
        'res_group_id' : fields.integer('Group ID'),
        'name' : fields.char('Group Name'),
        'is_read' : fields.boolean('Read'),
        'is_upload' : fields.boolean('Upload'),
        'is_comment' : fields.boolean('Comment'),
    }

class document_directory(osv.osv):
    _inherit = "document.directory"

    def _get_file_size(self, cr, uid, ids, name, arg, context=None):
        total_size = '';res = {}; size = 0.0;
        for record in self.browse(cr, uid, ids, context=context):
            if record.name:
                attac_file = self.pool.get('ir.attachment').browse(cr, uid, self.pool.get('ir.attachment').search(cr, uid, [('parent_id', '=', record.id)]))
                for files in attac_file:
                    size +=files.file_size
                total_size = self.sizeof_files(cr, uid, ids, size, context=context)
                size = 0.0
            if total_size:
                res[record.id] = total_size
        return res

    def sizeof_files(self, cr, uid, ids, num, context=None):
        suffix='B';
        for unit in ['',' K',' M',' G',' T',' P',' E',' Z']:
            if abs(num) < 1024.0:
                return "%3.1f%s%s" % (num, unit, suffix)
            num /= 1024.0
        return "%.1f%s%s" % (num, ' ' ,'Yi', suffix)

    ''' Load the access rights based on the directory type'''
    def onchange_directory_type(self, cr, uid, ids, directory_type, context=None):
        res_groups = [];
        if directory_type:
            res_groups_obj = self.pool.get('res.groups')
            document_id = self.pool.get('ir.module.category').search(cr, uid, [('name', '=', 'Document')], context=context)
            if document_id:
                groups = res_groups_obj.browse(cr, uid,res_groups_obj.search(cr, uid, [('category_id', '=', document_id[0])], context=context))
                if directory_type == 'public':
                    for record in groups:
                        values = {
                            'res_group_id' : record.id,
                            'name' : record.name,
                            'is_read' : True,
                            'is_upload' :True,
                            'is_comment' :True,
                        }
                        res_groups.append((0, 0, values))
                else:
                    for record in groups:
                        values = {
                            'res_group_id' : record.id,
                            'name' : record.name,
                            'is_read' : False,
                            'is_upload' :False,
                            'is_comment' :False,
                        }
                        res_groups.append((0, 0, values))
        return {'value': {'directory_rights_ids' : res_groups}}

    def _get_size(self, cr, uid, dir_id):
        size = 0
        attach_obj = self.pool.get('ir.attachment')
        file_ids = attach_obj.search(cr, uid, [('parent_id', '=', dir_id)])
        for f in attach_obj.browse(cr, uid, file_ids):
            size += f.file_size or 0
        child_ids = self.search(cr, uid, [('parent_id', '=', dir_id)])
        for child_id in child_ids:
            size += self._get_size(cr, uid, child_id)
        return size
    def _size_calc(self, cr, uid, ids, name, args, context=None):
        """ Finds size of the direcotry.
        @param name: Name of field.
        @param args none:
        @return: Dictionary of values.
        """
        result = {}
        for dir in self.browse(cr, uid, ids, context=context):
            result[dir.id] = self._get_size(cr, uid, dir.id)
        return result

    _columns={
         'description':fields.html('Description'),
         'is_active':fields.boolean('Active?', default=True),
         'directory_rights_ids' : fields.one2many('directory.rights', 'directory_document_id', 'File Access'),
         'directory_type': fields.selection([('public', 'Public'),('private', 'Private')],'Directory Type'),
         'created_by_id':fields.many2one('res.users', 'Created by', readonly=True,store=True),
         'file_size': fields.function(_size_calc, type='float', string='Total Size'),
     }
    _defaults = {
        'user_id':None
    }
    def create(self, cr, uid, vals, context=None):
        res_group = []
        directory = vals.get('directory_rights_ids')
        if directory:
            for record in directory:
                if 'is_read' in record[2]:
                    res_group.append(record[2]['res_group_id'])
                elif 'is_upload' in record[2]:
                    res_group.append(record[2]['res_group_id'])
                elif 'is_comment' in record[2]:
                    res_group.append(record[2]['res_group_id'])
            if res_group:
                vals.update({'group_ids':[[6, False, res_group]]})
        return super(document_directory, self).create(cr, uid, vals, context=context)


class directory_rights(osv.osv):
    _name = 'directory.rights'
    _description = 'Directory access rights'

    _columns = {
        'directory_document_id' : fields.many2one('document.directory', 'Document'),
        'res_group_id' : fields.integer('Group ID'),
        'name' : fields.char('Group Name'),
        'is_read' : fields.boolean('Read'),
        'is_upload' : fields.boolean('Upload'),
        'is_comment' : fields.boolean('Comment'),
    }

''' Author object created by susai '''

class author_author(osv.osv):
    _name = "author.author"
    _columns={

        'name': fields.char('Name',required = True),
}

class ir_config_parameter(osv.osv):
    _inherit = 'ir.config_parameter'

    _columns= {
        'total_memory_space':fields.char('Memory Space')
    }

