# README #

Satchmo is an eCommerce framework created in Django which allows you to develop unique and robust online stores.

### Learn More About Satchmo ###

* [Satchmo Docs](http://docs.satchmoproject.com)
* [Satchmo Site](http://www.satchmoproject.com)