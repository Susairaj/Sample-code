"""
Provides a simple "Recently Viewed" list function to Satchmo.
"""

__AUTHOR__ = "Bruce Kroeze <brucek@solidsitesolutions.com>"
