#TODO

+ On college creation, create a group named after it.
+ On event creation, create a permission for creator to edit event. Also create a group permission for that college if the privacy is set to College only.
+ Ask if user wants to host this event on CDI after event creation.
+ Show error messages when signing in and signing up.
+ Respect next parameter in url when signing in.
+ Show pretty msgs in all forms using model fields error messages and help text.
+ Add google maps api in event venue.
+ Use signals when a new event is created. And use it in making a new *base* sub-event for it.
+ Add JS in hiding manual venue and then display it when user click to add new venue.
+ Implement my events feature

----
#NOT Required now

+ Use some wysiwug editor in JS for description addition in events,subevents.

----
#DONE

+ Remove unnecessary entries in requirements
+ Remove dependancy on *uni-form* and add *Bootstrap*.
+ Bootstrappfy every form.
+ **Add venue to event model.**
