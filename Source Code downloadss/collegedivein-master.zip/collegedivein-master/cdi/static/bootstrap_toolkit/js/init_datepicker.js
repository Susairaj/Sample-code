(function($){
    $(function() {
        $('input[data-bootstrap-widget=datepicker]').datepicker();
    })
})(jQuery);
