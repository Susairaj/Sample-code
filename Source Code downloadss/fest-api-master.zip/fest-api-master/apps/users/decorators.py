from django.core.urlresolvers import reverse, reverse_lazy
from django.conf import settings
from django.contrib.auth.decorators import user_passes_test

