from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.forms import ModelForm
from django.utils.translation import ugettext as _

TYPE_CONTACT = (
    (u'C', _('Customer')),
    (u'S', _('Supplier')),
    (u'P', _('Peronal')),
    (u'G', _('Generic')),
)

class Contacts(models.Model):
    name            = models.CharField(max_length=80, verbose_name=_("Name"))
    surname         = models.CharField(max_length=50, blank=True,  verbose_name=_("Surname"))
    address         = models.CharField(max_length=80, verbose_name=_("Address"))
    zipcode         = models.CharField(max_length=10, verbose_name=_("Zip Code"))
    town            = models.CharField(max_length=50, verbose_name=_("Town"))
    province        = models.CharField(max_length=2, verbose_name=_("Province"))
    phone           = models.CharField(max_length=30, blank=True, verbose_name=_("Phone"))
    mobilephone     = models.CharField(max_length=30, blank=True, verbose_name=_("Mobile phone"))
    email           = models.CharField(max_length=30, blank=True, verbose_name=_("Email"))
    tp_contacts     = models.CharField(max_length=1, choices=TYPE_CONTACT, verbose_name=_("Type of contact"))
    vatnumber       = models.CharField(max_length=11, blank=True, verbose_name=_("VAT number"))
    personalId      = models.CharField(max_length=50, blank=True, verbose_name=_("Code for personal identification"))
    user            = models.ForeignKey(User)
    
    def __unicode__(self):
        return u"%s, %s" %(self.name, self.surname)
        
    class Meta:
        verbose_name_plural = "Contacts"
        verbose_name  = "Contact" 


class ContactsAdmin(admin.ModelAdmin):
    list_display = ('name', 'surname', 'address', 'zipcode', 'town','province')
    list_filter = ['name', 'surname']
    search_fields = ['name', 'surname']

admin.site.register(Contacts, ContactsAdmin)


class ContactsForm(ModelForm):
    class Meta:
        model = Contacts
        fields = ['name', \
                  'surname', \
                  'address', \
                  'zipcode', \
                  'town', \
                  'province', \
                  'phone', \
                  'mobilephone', \
                  'email', \
                  'tp_contacts',
                  'vatnumber', \
                  'personalId', ]
        


