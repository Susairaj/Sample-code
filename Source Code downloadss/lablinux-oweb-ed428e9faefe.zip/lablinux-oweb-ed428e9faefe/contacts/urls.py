from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()


urlpatterns = patterns('contacts.views' ,
    url(r'^/$'                     , 'index'  , name='contacts-index'),
    url(r'^/update/(?P<id>\d+)/$'   , 'update' , name='contacts-update'),
    url(r'^/new/$'                 , 'new'    , name='contacts-new'),
    url(r'^/delete/(?P<id>\d+)/$'   , 'delete' , name='contacts-delete'),
    url(r'^/ajax/(?P<id>\d+)/$'    , 'ajax' , name='contacts-ajax'),
)
