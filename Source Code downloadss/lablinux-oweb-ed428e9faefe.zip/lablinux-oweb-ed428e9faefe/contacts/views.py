from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from contacts.models import Contacts, ContactsForm
from django.utils.translation import ugettext as _
#from django.contrib.auth.models import User
import utility


from django import forms

#class MyForm(forms.Form):
#    def __init__(self, uid=0, *args, **kwargs):
#        super(MyForm, self).__init__(*args, **kwargs)
#        self.fields['contacts'] = forms.ChoiceField(choices=get_choices(uid))

#def get_choices(userid=0):
#    contacts = Contacts.objects.filter(user=userid)
#    return [(contact.id,contact.name) for contact in contacts]


@login_required
def ajax(request, id=None):
    contact = Contacts.objects.get(id=id)
    return render_to_response('contacts/ajax.html' ,
                             {'contact'    : contact,} ,
                               context_instance=RequestContext(request))

@login_required
def index(request):
    contacts = Contacts.objects.filter(user=request.user.id)
    return render_to_response('contacts/index.html' ,
                             {'contacts'    : contacts,} ,
                               context_instance=RequestContext(request))

@login_required
def update(request, id=None):
    return utility.update(Contacts, ContactsForm, request, id, 'contacts-index', 'crud/update.html', title=_('Update contact'))

@login_required
def new(request):
    return utility.new(ContactsForm, request, 'contacts-index', 'crud/new.html', title=_('New contact'))

@login_required
def delete(request, id=None):
    return utility.delete(Contacts, request, id, 'contacts-index')


