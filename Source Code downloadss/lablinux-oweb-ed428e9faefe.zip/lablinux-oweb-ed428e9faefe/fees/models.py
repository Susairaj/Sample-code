from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.forms import ModelForm
from django.utils.translation import ugettext as _

class Fees(models.Model):
    """
    in italian "Tasse e tributi"
    Every item can have more fees. Evry fee have a applystep to calculate the fee
    The step '0' is the gross
    """
    code = models.CharField(blank=True, unique=True, max_length=15, verbose_name=_("Code"))
    description = models.CharField(max_length=80, verbose_name=_("Description"))
    percentage = models.FloatField(verbose_name=_("Percentage"))
    #applystep = models.SmallIntegerField(verbose_name=_("Apply to step"))
    #step = models.SmallIntegerField(verbose_name=_("Step"))
    user = models.ForeignKey(User)
    
    def __unicode__(self):
        return u"%s, %s" %(self.description, self.percentage)
        
    class Meta:
        verbose_name_plural = _("Fees")
        verbose_name  = _("Fee")

    def save(self):
        super(Fees, self).save()
        if self.code == None or self.code == '':
            self.code = "code_%d" % self.id
            super(Fees, self).save()

class FeesAdmin(admin.ModelAdmin):
    list_display = ('description', 'percentage',)
    list_filter = ['description',]
    search_fields = ['description',]

admin.site.register(Fees, FeesAdmin)


class FeesForm(ModelForm):
    class Meta:
        model = Fees
        fields = ['code', \
                  'description', \
                  'percentage',  ]
        