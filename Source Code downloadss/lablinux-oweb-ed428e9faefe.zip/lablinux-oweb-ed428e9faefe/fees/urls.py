from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()


urlpatterns = patterns('fees.views' ,
    url(r'^/$'                     , 'index'  , name='fees-index'),
    url(r'^/update/(?P<id>\d+)/$'   , 'update' , name='fees-update'),
    url(r'^/new/$'                 , 'new'    , name='fees-new'),
    url(r'^/delete/(?P<id>\d+)/$'   , 'delete' , name='fees-delete'),
    url(r'^/ajax_list/(?P<idx>\d+)/(?P<id>\d+)/$' , 'ajax_list'   , name='fees-ajax-list'),    
    url(r'^/ajax_list/(?P<idx>\d+)/$' , 'ajax_list'   , name='fees-ajax-list'),

)
