from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from fees.models import Fees, FeesForm
from django import forms
import utility

def get_choices(userid=None):
    fees = Fees.objects.filter(user=userid)
    return [(fee.id,fee.description[0:30]) for fee in fees]

class formFee(forms.Form):
    def __init__(self, uid=None, nameField=None, *args, **kwargs):
        super(formFee, self).__init__(*args, **kwargs)
        self.fields['Fee'] = forms.ChoiceField(choices=get_choices(uid))
        self.fields['Fee_descr'] = forms.CharField(label="additional info")

@login_required
def ajax_list(request, idx=None, id=None):
    form = formFee(uid=request.user.id)
    return render_to_response('fees/ajax_list.html' , 
                             {'form' : form,
                              'idx' : idx, 
                              'id' : int(id)} ,
                               context_instance=RequestContext(request))
        
@login_required
def index(request):
    fees = Fees.objects.filter(user=request.user.id)
    return render_to_response('fees/index.html' , 
                             {'fees'    : fees,} ,
                               context_instance=RequestContext(request))

@login_required
def update(request, id=None):
    return utility.update(Fees, FeesForm, request, id, 'fees-index', 'crud/update.html')

@login_required
def new(request):
    return utility.new(FeesForm, request, 'fees-index', 'crud/new.html')

@login_required
def delete(request, id=None):
    return utility.delete(Fees, request, id, 'fees-index')


