from django.shortcuts import render_to_response
from django.template import RequestContext

def index(request):
    if request.method == 'POST':
        reqout = []
        reqout.append(request.REQUEST['firstname'])
        reqout.append(request.REQUEST['lastname'])
        #for r in request.REQUEST:
        #    reqout.append(r)
        return render_to_response('home/index.html' ,
                                 {'reqout' : reqout,} ,
                                   context_instance=RequestContext(request))
    else:
         return render_to_response('home/index.html' ,
                                 {} ,
                                   context_instance=RequestContext(request))
