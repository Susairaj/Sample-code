# -*- coding: iso-8859-1 -*-
from django.db  import models
from django.contrib.auth.models import User
from items.models import Items
from contacts.models import Contacts
from payterms.models import Payterms
from django.contrib import admin
from django.forms  import ModelForm
from django.db.models import Max
from datetime import datetime
from django.utils.translation import ugettext as _
from datetime import datetime

from settings import MEDIA_URL_USER_DOCS

INVOICE_STATUS = (
    (u'D', _('Draft') ),
    (u'I', _('Issue') ),
    (u'P', _('Paid') ),
)

def content_file_name(instance, filename):
    return '/'.join([MEDIA_URL_USER_DOCS, '1' , filename])

class InvoiceHeaders(models.Model):
    issuer = models.ForeignKey(Contacts, related_name='invoices_issuer', limit_choices_to={"tp_contacts":"P", })
    customer = models.ForeignKey(Contacts, related_name='invoices_custumer', limit_choices_to={"tp_contacts":"C", })
    payterm = models.ForeignKey(Payterms, related_name='invoices_payterm')
    user = models.ForeignKey(User)
    pdf = models.FileField(upload_to=content_file_name)
    findrandomnumber = models.CharField(unique=True,max_length=56)

    number = models.PositiveIntegerField(null=True, blank=True, verbose_name = _("Number issue"))
    yearissue = models.PositiveIntegerField(null=True, blank=True, verbose_name = _("Year issue"))
    dateissue = models.DateField(null=True, blank=True, verbose_name = _("Date issue"))
    status = models.CharField(max_length=1, choices=INVOICE_STATUS, verbose_name=_("status"))

    issuer_name = models.CharField(max_length = 80, verbose_name = _("My Name"))
    issuer_surname = models.CharField(max_length = 80, verbose_name = _("My Surname"))
    issuer_address = models.CharField(max_length = 80, verbose_name = _("My Address"))
    issuer_zipcode = models.CharField(max_length = 10, verbose_name = _("My Zip Code"))
    issuer_town = models.CharField(max_length = 50, verbose_name = _("My Town"))
    issuer_province = models.CharField(max_length = 2, verbose_name = _("My Province"))
    issuer_vatnumber = models.CharField(max_length = 11, verbose_name = _("My VAT number"))

    customer_name = models.CharField(max_length = 80, verbose_name = _("Customer Name"))
    customer_surname = models.CharField(max_length = 80, verbose_name = _("Customer Surname"))
    customer_address = models.CharField(max_length = 80, verbose_name = _("Customer Address"))
    customer_zipcode = models.CharField(max_length = 10, verbose_name = _("Customer Zip Code"))
    customer_town = models.CharField(max_length = 50, verbose_name = _("Customer Town"))
    customer_province = models.CharField(max_length = 2, verbose_name = _("Customer Province"))
    customer_vatnumber = models.CharField(null=True,  blank=True,  max_length = 11, verbose_name = _("Customer VAT number"))

    pay_term01 = models.CharField(null=True, blank=True, max_length = 80, verbose_name = _("Payterm 1"))
    pay_term02 = models.CharField(null=True, blank=True, max_length = 80, verbose_name = _("Payterm 2"))
    pay_term03 = models.CharField(null=True, blank=True, max_length = 80, verbose_name = _("Payterm 3"))


    def __unicode__(self):
        return u"%s - %s, %s" %(self.number, self.dateissue, self.customer_name)

    class Meta:
        verbose_name_plural = _('Invoice Headers')
        verbose_name  = _('Invoice Header')
        unique_together = (('number', 'yearissue', 'user'),)



    def nextnumber(self, uid = None, year = None):
        return self.maxnumber(uid = uid, year = year) + 1

    def maxnumber(self, uid = None, year = None):
        if uid == None:
            return -1
        if year == None:
               year = datetime.now().year
        maxnum = InvoiceHeaders.objects.filter(user = uid).filter(dateissue__year = year).aggregate(Max('number'))
        num = maxnum['number__max']
        if num:
            return num
        else:
            return 0

    def save(self, number=None, dateissue=None):
        #force = False
        if self.status == 'I' and self.dateissue == None:
            if dateissue == None:
                self.dateissue = datetime.today()
                self.yearissue = datetime.today().year
            else:
                self.dateissue = dateissue
                self.yearissue = dateissue[0:4]
            if number == None:
                self.number = self.nextnumber(uid = self.user, year = self.dateissue.year )
            else:
                self.number = number
        #if InvoiceHeaders.objects.filter(dateissue__year=form['date'].data[6:10]).filter(number=form['number'].data):
        #    return False
        #    self.error = '%s : %s / %s' %( _('ErrdupKey'), form['date'].data[6:10], form['number'].data)

        self.issuer_name = self.issuer.name
        self.issuer_surname = self.issuer.surname
        self.issuer_address = self.issuer.address
        self.issuer_zipcode = self.issuer.zipcode
        self.issuer_town = self.issuer.town
        self.issuer_province = self.issuer.province
        self.issuer_vatnumber = self.issuer.vatnumber

        self.customer_name = self.customer.name
        self.customer_surname = self.customer.surname
        self.customer_address = self.customer.address
        self.customer_zipcode = self.customer.zipcode
        self.customer_town = self.customer.town
        self.customer_province = self.customer.province
        self.customer_vatnumber = self.customer.vatnumber

        self.pay_term01 = self.payterm.description1
        self.pay_term02 = self.payterm.description2
        self.pay_term03 = self.payterm.description3

        super(InvoiceHeaders, self).save()

        #if force:
        #for ib in self.invoicebodies_set.all():
        #    ib.save() #force=force)

class InvoiceHeadersModel(ModelForm):
    class Meta:
        model = InvoiceHeaders

class InvoiceHeadersAdmin(admin.ModelAdmin):
    list_display = ('number', 'dateissue', 'customer_name', 'customer_surname')
    list_filter = ['dateissue', 'customer_name', 'customer_surname']
    search_fields = ['dateissue', 'customer_name', 'customer_surname']

admin.site.register(InvoiceHeaders, InvoiceHeadersAdmin)


class InvoiceBodies(models.Model):
    item = models.ForeignKey(Items)
    header = models.ForeignKey(InvoiceHeaders)

    unitprice = models.FloatField(null=True, verbose_name=_('Unit price'))
    unitmeasurement = models.CharField(null=True, max_length=80, verbose_name=_("Unit measure"))
    description =  models.CharField(null=True, max_length=80, verbose_name=_("Description"))
    extraDescription =  models.CharField(null=True, max_length = 80, verbose_name = _("Extra Description"))
    quantity  = models.FloatField(null=True, verbose_name = 'Quantity')


    def __unicode__(self):
        return '%s:  %s ' %( _("Extra Description"), self.extraDescription,)

    class Meta:
        verbose_name_plural = _("Invoice Bodies ")
        verbose_name  = _("Invoice Body ")

    def save(self): #, force=None):
        self.unitprice = self.item.unitprice
        self.unitmeasurement = self.item.unitmeasurement
        self.description = self.item.description

        super(InvoiceBodies, self).save()

        # cancello i fees legati al body per ricaricarli
        self.invoicebodiesfees_set.all().delete()
        for fee in self.item.fees.values():
            ibs = InvoiceBodiesFees()
            ibs.body = self
            ibs.description = fee['description']
            ibs.percentage = fee['percentage']
            ibs.save()

class InvoiceBodiesAdmin(admin.ModelAdmin):
    list_display = ('extraDescription', )
    list_filter = ['extraDescription', ]
    search_fields = ['extraDescription', ]

admin.site.register(InvoiceBodies, InvoiceBodiesAdmin)



class InvoiceBodiesFees(models.Model):
    body = models.ForeignKey(InvoiceBodies)

    description = models.CharField(max_length=80, verbose_name=_("Description"))
    percentage = models.FloatField(verbose_name=_("Percentage"))

    def __unicode__(self):
        return u"%s" %self.description