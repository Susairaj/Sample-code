from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import *
from reportlab.lib import colors
from reportlab.lib.units import cm
from cStringIO import StringIO
import utility

from django.utils.translation import ugettext as _

class printPDF():
    def __init__(self, iheader=None, ibodies=None):
        self.iheader=iheader
        self.ibodies = ibodies

    def generate(self,  path_to_save=None):
        buffer = StringIO()
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Pop', fontName='Times-Roman', fontSize=12, leading=1), alias='pop')
        styles.add(ParagraphStyle(name='PopBold', fontName='Times-Bold', fontSize=13, leading=1), alias='popbold')
        styles.add(ParagraphStyle(name='PopLitle', fontName='Times-Roman', fontSize=8, leading=1), alias='poplitle')
        
        c = canvas.Canvas(buffer)
                
        headingstyle = styles['Pop']
        # my info
        p = Paragraph("%s %s" %(self.iheader.my_name, self.iheader.my_surname), headingstyle)
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 3 * cm, 26 * cm)

        p = Paragraph(self.iheader.my_address, headingstyle)
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 3 * cm, 25.5 * cm)
        
        p = Paragraph("%s %s (%s)" %(self.iheader.my_zipcode, self.iheader.my_town, self.iheader.my_province), headingstyle) 
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 3 * cm, 25 * cm)
        
        p = Paragraph("%s %s" %(_('vat'),  self.iheader.my_vatnumber), headingstyle)
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 3 * cm, 24.5 * cm)

        # custumer info
        p = Paragraph("%s %s" %(self.iheader.costumer_name, self.iheader.costumer_surname), headingstyle) 
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 13 * cm, 25 * cm)

        p = Paragraph(self.iheader.costumer_address, headingstyle)
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 13 * cm, 24.5 * cm)
        
        p = Paragraph("%s %s (%s)" %(self.iheader.costumer_zipcode, self.iheader.costumer_town, self.iheader.costumer_province), headingstyle)
        p.wrapOn(c, 6 * cm, 0 * cm)
        p.drawOn(c, 13 * cm, 24 * cm)
    
        if len(self.iheader.costumer_vatnumber) > 0:
            p = Paragraph("p. iva %s" %(self.iheader.costumer_vatnumber), headingstyle)
            p.wrapOn(c, 6 * cm, 0 * cm)
            p.drawOn(c, 13 * cm, 23.5 * cm)

        if self.iheader.status == 'D':
            p = Paragraph("DRAFT" , headingstyle)
            p.wrapOn(c, 7.2 * cm, 8 * cm)
            p.drawOn(c, 8 * cm, 22 * cm)
        else:
            p = Paragraph("%s %s %d %s %s" %(_('Invoice'), _('#') ,self.iheader.number, _('of'), utility.date_ita(self.iheader.dateissue) ), styles['PopBold'])
            p.wrapOn(c, 7.2 * cm, 8 * cm)
            p.drawOn(c, 8 * cm, 22 * cm)

        row = 18
        elements = []
        styles = getSampleStyleSheet()
        data = []
        for ibody in self.ibodies:
            dataRow = [ibody.description]
            dataRow.append('%19.2f' %ibody.total)
            dataRow.append(' %9.2f ' %ibody.unitprice)
            dataRow.append('* %9.2f' %ibody.amount)
            #p = Paragraph(ibody.description, styles['Pop'])
            #p.wrapOn(c, 15 * cm, 0 * cm)
            #p.drawOn(c, 2 * cm, row * cm)

            #p = Paragraph('%19.2f' %ibody.total, styles['Pop'])
            #p.wrapOn(c, 0 * cm, 0 * cm)
            #p.drawOn(c, 12 * cm, row  * cm)
            
            #outData = ''
            #outData += ' %9.2f ' %ibody.unitprice 
            #outData += ' * %9.2f' %ibody.amount 
            #outData += '(%s)' %ibody.unitmeasurement 
            #p = Paragraph(outData, styles['PopLitle'])
            #p.wrapOn(c, 90 * cm, 90 * cm)
            #p.drawOn(c, 15 * cm, row * cm)
            
            
            if ibody.vat_total > 0:
              dataRow.append(_('Vat'))
              dataRow.append(ibody.vat)
              dataRow.append(ibody.vat_total)
              #outData = '%s %s%s %8.2f ' %(_('Vat'),  ibody.vat, '%', ibody.vat_total)
              #row-=0.3
              #p = Paragraph(outData, styles['PopLitle'])
              #p.wrapOn(c, 90 * cm, 90 * cm)
              #p.drawOn(c, 15 * cm, row * cm)
            if ibody.contribution_total != 0:
              dataRow.append(_('Contribution'))
              dataRow.append(ibody.contribution)
              dataRow.append(ibody.contribution_total)
              #outData = '%s %s%s %8.2f'  %(_('Contribution'),  ibody.contribution, '%', ibody.contribution_total)
              #row-=0.3
              #p = Paragraph(outData, styles['PopLitle'])
              #p.wrapOn(c, 90 * cm, 90 * cm)
              #p.drawOn(c, 15 * cm, row * cm)
            if ibody.taxdeduced_total != 0:
              dataRow.append(_('Tax deduced'))
              dataRow.append(ibody.taxdeduced)
              dataRow.append(ibody.taxdeduced_total)
              #outData = '%s %s%s %8.2f ' %(_('Tax deduced'),  ibody.taxdeduced, '%', ibody.taxdeduced_total)
              #row-=0.3
              #p = Paragraph(outData, styles['PopLitle'])
              #p.wrapOn(c, 90 * cm, 90 * cm)
              #p.drawOn(c, 15 * cm, row * cm)

            #row -= 1.5
            data.append(dataRow)
        ts = [('ALIGN', (1,1), (-1,-1), 'CENTER'),
             ('LINEABOVE', (0,0), (-1,0), 1, colors.purple),
             ('LINEBELOW', (0,0), (-1,0), 1, colors.purple),
             ('FONT', (0,0), (-1,0), 'Times-Bold'),
             ('LINEABOVE', (0,-1), (-1,-1), 1, colors.purple),
             ('LINEBELOW', (0,-1), (-1,-1), 0.5, colors.purple,
              1, None, None, 4,1),
             ('LINEBELOW', (0,-1), (-1,-1), 1, colors.red),
             ('FONT', (0,-1), (-1,-1), 'Times-Bold')]
            
        table = Table(data, style=ts)
        elements.append(table)

        f=Frame(10,10,550,800)
        f.addFromList(table,c)

        c.showPage()
        c.save()
        
        
        pdf = buffer.getvalue()
        buffer.close()
        
        if path_to_save:
            f = file("path_to_save", "wb")
            f.write(pdf)
            f.close()

        return pdf
