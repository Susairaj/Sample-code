# -*- coding: iso-8859-1 -*-
from django import template
from django.utils.translation import ugettext
from django.utils.safestring import mark_safe
import locale
locale.setlocale(locale.LC_ALL, '')

register = template.Library()
 
 
@register.filter()
def currency(value):
    try:
        return mark_safe(  '%s %s' %(locale.currency(value, symbol=False, grouping=True), ugettext('currency')) )
    except:
        return '-err-'



