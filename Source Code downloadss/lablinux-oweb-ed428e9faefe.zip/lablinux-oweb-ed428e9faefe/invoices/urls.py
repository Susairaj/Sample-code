from django.conf.urls.defaults import *
from django.conf import settings

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('invoices.views' ,
    url(r'^/$', 'index',  name='invoices-index'),
    url(r'^/new/$', 'new',  name='invoices-new'),
    url(r'^/update/(?P<id>\d+)/$', 'update',  name='invoices-update'),
    url(r'^/status/(?P<id>\d+)/$', 'status',  name='invoices-status'),
    url(r'^/issue/(?P<id>\d+)/$', 'issue',  name='invoices-issue'),
    url(r'^/payd/(?P<id>\d+)/$', 'payd',  name='invoices-payd'),
    url(r'^/pdfhtml/(?P<id>\d+)/$', 'pdfhtml',  name='invoices-pdfhtml'),
    url(r'^/additem/$', 'additem',  name='invoices-additem'),
    url(r'^/download/(?P<id>\d+)/$', 'download',  name='invoices-download'),
    url(r'^/getit/(?P<findrandomnumber>\w{56})/$', 'getit',  name='invoices-getit'),
    url(r'^/delete/(?P<id>\d+)/$'            , 'delete' , name='invoices-delete'),
    #url(r'^/ajaxgetit/(?P<findrandomnumber>\w{56})/$', 'ajaxgetit',  name='invoices-ajaxgetit'),
)


##url(r'^/pdf/(?P<id>\d+)/$', 'pdf',  name='invoicehes-pdf'),
##url(r'^/update/(?P<id>\d)/$'            , 'update' , name='invoicehes-update'),
