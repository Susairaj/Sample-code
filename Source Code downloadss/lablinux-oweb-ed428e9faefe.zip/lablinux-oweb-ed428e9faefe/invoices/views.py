# -*- coding: iso-8859-1 -*-
from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django import forms
from django.conf import settings
from django.contrib.auth.models import User
from django.utils.translation import ugettext as _
from django.core.files import File

from invoices.models  import InvoiceHeaders, InvoiceBodies, InvoiceHeadersModel #invoicehesForm, , InvoiceBodiesForm
from contacts.models import Contacts
from payterms.models import Payterms
from items.models import Items

from settings import MEDIA_ROOT, MEDIA_URL_USER_DOCS

from datetime import datetime, timedelta
from calendar import monthrange
#from os import mkdir, chdir
from time import time
from hashlib import sha224
from os.path import normpath
import utility

def get_choicesContacts(userid=None, typeUser=None):
    contacts = Contacts.objects.filter(user=userid).filter(tp_contacts=typeUser)
    return [(contact.id,contact.name) for contact in contacts]

def get_choicesPayterms(userid=None):
    payterms = Payterms.objects.filter(user=userid)
    return [(payterm.id,"%s - %s - %s" %(payterm.description1[0:10],payterm.description2[0:10] , payterm.description3[0:10])) for payterm in payterms]

class formInvoice(forms.Form):
    def __init__(self, uid=None, *args, **kwargs):
        super(formInvoice, self).__init__(*args, **kwargs)
        if uid!=None:
            self.fields['Issuer'] = forms.ChoiceField(choices=get_choicesContacts(uid, 'P'))
            self.fields['Custumer'] = forms.ChoiceField(choices=get_choicesContacts(uid, 'C'))
            self.fields['Payterm'] = forms.ChoiceField(choices=get_choicesPayterms(uid))
            #self.fields['Item'] = forms.ChoiceField(choices=get_choicesItems(uid))
            #self.fields['Item_descr'] = forms.CharField(label="additiona info")

class FormNewInvoice(forms.Form):
    number = forms.IntegerField(label='number')
    date = forms.DateField(label="issue date", input_formats=['%d/%m/%Y'])

def getit(request, findrandomnumber=None):
    i = InvoiceHeaders.objects.filter(findrandomnumber=findrandomnumber)[0]
    nomefile = normpath(MEDIA_ROOT +  i.pdf.name.split('media')[1])
    f = open(normpath(MEDIA_ROOT +  i.pdf.name.split('media')[1]), 'rb')
    stream = f.readlines()
    f.close()
    #invoiceheader = InvoiceHeaders.objects.get(id=id)
    #invoiceheader.pdf.open()
    #stream = invoiceheader.pdf.readlines()
    #invoiceheader.pdf.close()
    return HttpResponse(stream, mimetype='application/pdf')


@login_required
def index(request):
    invoices = InvoiceHeaders.objects.filter(user=request.user.id).order_by('-status', 'number')
    return render_to_response('invoices/index.html' ,
                              {'invoices' : invoices,
                              'current_site' : request.META['HTTP_HOST'],
                              'current_path' : request.META['PATH_INFO'],
                              'r' : request.path , },
                               context_instance=RequestContext(request))
@login_required
def pdfhtml(request, id=None):
    pdfHtml = _generate_pdf(id)
    return HttpResponse(pdfHtml.getvalue(), mimetype='application/pdf')

    #return HttpResponse("PDF ERROR! %s" % pdf.err)

    response = render_to_response('invoices/pdf.html' ,  \
                              {'invoiceheader' : invoiceheader, \
                              'invoicebody' : invoicebody,} , \
                               context_instance=RequestContext(request))

    return render_to_response('invoices/pdf.html' ,  \
                              {'invoiceheader' : invoiceheader, 'invoicebody' : invoicebody,} , \
                               context_instance=RequestContext(request))


@login_required
def status(request, id=None):

    #from django.core.files.uploadedfile import InMemoryUploadedFile
    from django.core.files.base import ContentFile

    invoiceheader = InvoiceHeaders.objects.get(id=id)
    error = None
    mydate = datetime.now()
    mydate = mydate - timedelta(days=mydate.day)
    dateissue = "%s/%s/%s" %(monthrange(mydate.year,  mydate.month)[1] , mydate.month, mydate.year)
    number = invoiceheader.nextnumber (uid=request.user.id, year=mydate.year)
    number_next = None

    if request.method == 'POST':
        form = FormNewInvoice(request.POST)
        if form.is_valid():
            dataDb =  "%s-%s-%s" %(form['date'].data[6:10], form['date'].data[3:5] ,form['date'].data[0:2])
            dateissue = form['date'].data
            #number_next = invoiceheader.nextnumber (uid=request.user.id)
            number = form['number'].data
            #if InvoiceHeaders.objects.filter(dateissue__year=form['date'].data[6:10]).filter(number=form['number'].data):
            #    error = '%s : %s / %s' %( _('ErrdupKey'), form['date'].data[6:10], form['number'].data)
            #else:
            invoiceheader.status = 'I'
            invoiceheader.save(number = number, dateissue = dataDb)
            filename = '%s-%s.pdf' %(invoiceheader.dateissue, invoiceheader.number )
            pdfInvoice = _generate_pdf(id)
            #file = InMemoryUploadedFile(pdfInvoice, "pdf", filename, None, pdfInvoice.tell(), None)
            #invoiceheader.pdf.save(file.name, file)

            #content = File(file=pdfInvoice.getvalue(), name=filename)
            #pdfInvoice.name = filename
            #content = File({'name': filename, 'content':pdfInvoice})

            invoiceheader.pdf.save(filename, ContentFile(pdfInvoice.getvalue()))
            invoiceheader.findrandomnumber=sha224( "%f-%s"%(time(),filename) ).hexdigest()

            invoiceheader.save()
            #pathDocs = '%s/%s' %(MEDIA_URL_USER_DOCS,invoiceheader.user.id)
            #try:
            #    chdir(pathDocs)
            #except:
            #    mkdir(pathDocs)
            #f = open(invoiceheader.pdf.path,  'wb')
            #f.write(pdfInvoice.getvalue())
            #f.flush()
            #f.close()

            #f = open('%s/%s' %(pathDocs, 'to.txt'), 'w')
            #f.write(invoiceheader.pdf.path)
            #f.write('\n\r')
            #f.write('/'.join([MEDIA_URL_USER_DOCS, '%s' %request.user.id, 'filename']))
            #f.write('\n\r')
            #f.write(MEDIA_URL_USER_DOCS)
            #f.write(pdfInvoice.getvalue())
            #f.flush()
            #f.close()

            return HttpResponseRedirect(reverse ('invoices-index'))
    #else:

    form = FormNewInvoice({'number': number,
                           'date': dateissue})
    return render_to_response('invoices/status.html' ,
                             {'invoiceheader' : invoiceheader,
                              'form': form,
                              'number_next': number_next ,
                              'error': error} ,
                                   context_instance=RequestContext(request))

@login_required
def issue(request,  id=None):
    invoiceheader = InvoiceHeaders.objects.get(id=id)
    invoiceheader.status = 'I'
    invoiceheader.save()
    return HttpResponseRedirect(reverse ('invoices-index'))

@login_required
def payd(request,  id=None):
    invoiceheader = InvoiceHeaders.objects.get(id=id)
    invoiceheader.status = 'P'
    invoiceheader.save()
    return HttpResponseRedirect(reverse ('invoices-index'))

@login_required
def download(request, id=None):
    i = InvoiceHeaders.objects.get(id=id)
    nomefile = normpath(MEDIA_ROOT +  i.pdf.name.split('media')[1])
    f = open(normpath(MEDIA_ROOT +  i.pdf.name.split('media')[1]), 'rb')
    stream = f.readlines()
    f.close()
    #invoiceheader = InvoiceHeaders.objects.get(id=id)
    #invoiceheader.pdf.open()
    #stream = invoiceheader.pdf.readlines()
    #invoiceheader.pdf.close()
    return HttpResponse(stream, mimetype='application/pdf')


@login_required
def new(request):
    error = ''
    if request.method == 'POST':
        itemFound = False
        for id in range(1, int(request.REQUEST['numberitem']) + 1):
            if request.REQUEST.get('Item_%s' %id):
                itemFound = True
                break
        if itemFound:
            user = User.objects.get(id = request.user.id)
            issuer =  Contacts.objects.get(id = int(request.REQUEST['Issuer']) )
            customer = Contacts.objects.get(id = int(request.REQUEST['Custumer']) )
            payterm = Payterms.objects.get(id = int(request.REQUEST['Payterm']) )
            ihd = InvoiceHeaders()
            ihd.user = user
            ihd.issuer = issuer
            ihd.payterm = payterm
            ihd.customer = customer
            ihd.status = 'D'
            ihd.findrandomnumber=sha224( "%f"%(time()) ).hexdigest()

            ihd.save()

            for id in range(1, int(request.REQUEST['numberitem']) + 1):
                if request.REQUEST.get('Item_%s' %id):
                    ibd = InvoiceBodies()
                    ibd.header = ihd
                    ibd.quantity = float(request.REQUEST['Item_qta_%s' %id].replace(',','.'))
                    items = Items.objects.get(id = int(request.REQUEST['Item_%s' %id]) )
                    ibd.item = items
                    ibd.extraDescription = request.REQUEST['Item_descr_%s' %id].strip()
                    ibd.save()
            return HttpResponseRedirect(reverse ('invoices-index'))
        else:
            error = _('Item is obbligatory')

    form = formInvoice(uid=request.user.id) # An unbound form
    custumer_selected = 3
    return render_to_response('invoices/new2.html' ,
                            {'form': form,
                             'custumer_selected' : custumer_selected ,
                             'error' : error, },
                             context_instance=RequestContext(request))
@login_required
def update(request, id=None):
    error = ''
    invoice = get_object_or_404(InvoiceHeaders, id=id, user=request.user.id)
    if request.method == 'POST':
        itemFound = False
        for id in range(1, int(request.REQUEST['numberitem']) + 1):
            if request.REQUEST.get('Item_%s' %id):
                itemFound = True
                break
        if itemFound:
            for body in invoice.invoicebodies_set.all():
                body.delete()

            user = User.objects.get(id = request.user.id)
            issuer =  Contacts.objects.get(id = int(request.REQUEST['Issuer']) )
            customer = Contacts.objects.get(id = int(request.REQUEST['Custumer']) )
            payterm = Payterms.objects.get(id = int(request.REQUEST['Payterm']) )
            invoice.user = user
            invoice.issuer = issuer
            invoice.payterm = payterm
            invoice.customer = customer

            invoice.save()

            for id in range(1, int(request.REQUEST['numberitem']) + 1):
                if request.REQUEST.get('Item_%s' %id):
                    ibd = InvoiceBodies()
                    ibd.header = invoice
                    ibd.quantity = float(request.REQUEST['Item_qta_%s' %id].replace(',','.'))
                    items = Items.objects.get(id = int(request.REQUEST['Item_%s' %id]) )
                    ibd.item = items
                    ibd.extraDescription = request.REQUEST['Item_descr_%s' %id]
                    ibd.save()

            return HttpResponseRedirect(reverse ('invoices-index'))
        else:
            error = _('Item is obbligatory')

    form = formInvoice(uid=request.user.id) # An unbound form
    issuer_id = invoice.issuer_id
    customer_id = invoice.customer_id
    return render_to_response('invoices/update.html' ,
                             {'form': form,
                              'invoice' : invoice,
                              'issuer_id' : issuer_id,
                              'error' : error,
                              'customer_id' : customer_id,
                              'r' : request.path , },
                               context_instance=RequestContext(request))

def sendemail():
    from django.core.mail import EmailMessage
    email = EmailMessage('prova oweb', 'link fattura ...',to=['m_casari@yahoo.com'])
    email.send()

def delete(request, id=None):
    return utility.delete(InvoiceHeaders, request, id, 'invoices-index')

def additem(request):
    if request.is_ajax():
        q = request.GET.get( 'q' )
        if q is not None:
            form = formInvoice(uid=q) # An unbound form
            return render_to_response('invoices/_item.html' ,
                                    {'form': form,} ,
                                       context_instance=RequestContext(request))

def _generate_pdf(id=None):
    from django.template.loader import get_template
    from django.template import Context
    from cStringIO import StringIO
    import ho.pisa as pisa
    invoiceheader = InvoiceHeaders.objects.get(pk=id)
    bodies = []
    gros = 0
    net = 0
    taxtotal = 0
    taxes = {}
    for body in invoiceheader.invoicebodies_set.values():
        body['tax'] = []
        body['net'] = 0
        tax = 0
        body['gros'] = body['unitprice'] * body['quantity']
        for fees in InvoiceBodies.objects.get(pk=body['id']).invoicebodiesfees_set.all():
            body['tax'].append({'name':fees.description, 'value':( body['gros'] / 100 ) * fees.percentage} )
            if taxes.has_key(fees.description):
                taxes[fees.description] += ( body['gros'] / 100 ) * fees.percentage
            else:
                taxes[fees.description] = ( body['gros'] / 100 ) * fees.percentage
            print taxes
            tax += ( body['gros'] / 100 ) * fees.percentage
        gros += body['gros']
        body['net'] = body['gros'] + tax
        taxtotal += tax
        bodies.append(body)
    net = gros + taxtotal
    template = get_template('invoices/pdf.html')
    context = Context({'invoiceheader' : invoiceheader, \
                       'bodies' : bodies, \
                       'gros' : gros, \
                       'tax' : taxtotal, \
                       'taxes' : taxes, \
                       'net' : net, \
                       'MEDIA_ROOT' : MEDIA_ROOT})
    html = template.render(context)
    result = StringIO()
    pdf = pisa.pisaDocument(StringIO(html.encode("utf8")), result)
    return result

    ##f = open('%s/%s-%s-%s.pdf' %(MEDIA_ROOT,invoiceheader.user.id,invoiceheader.dateissue,invoiceheader.number), 'w')
    #if invoiceheader.number:
    #    pathDocs = '%s/%s' %(MEDIA_URL_USER_DOCS,invoiceheader.user.id)
    #    try:
    #        chdir(pathDocs)
    #    except:
    #        mkdir(pathDocs)
    #    #result.seek(0)
    #    f = open('%s/%s-%s.pdf' %(pathDocs, invoiceheader.dateissue, invoiceheader.number ), 'wb')
    #    f.write(result.getvalue())
    #    f.flush()
    #    f.close()


    ##f.write(result.getvalue())
    ##f.flush()
    ##f.close()
    ##if not pdf.err:
    ##    f = open('%s/workfile.pdf' %MEDIA_ROOT, 'w')
    ##    f.write(result.getvalue())
    ##    f.flush()
    ##    f.close()

    #    return HttpResponse(result.getvalue(), mimetype='application/pdf')

    #return HttpResponse("PDF ERROR! %s" % pdf.err)

    #response = render_to_response('invoices/pdf.html' ,  \
    #                          {'invoiceheader' : invoiceheader, \
    #                          'invoicebody' : invoicebody,} , \
    #                           context_instance=RequestContext(request))

    #return render_to_response('invoices/pdf.html' ,  \
    #                          {'invoiceheader' : invoiceheader, 'invoicebody' : invoicebody,} , \
    #                           context_instance=RequestContext(request))
