from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.forms import ModelForm
from django.utils.translation import ugettext as _
from fees.models import Fees

class Items(models.Model):
    unitprice = models.FloatField(verbose_name=_('Unit price'))
    unitmeasurement = models.CharField(max_length=80, verbose_name=_("Unit measure"))
    description =  models.CharField(max_length=80, verbose_name=_("Description"))
    #vat = models.FloatField(verbose_name=_('Vat'))
    #contribution = models.FloatField(verbose_name=_('Contribution'))
    #taxdeduced = models.FloatField(verbose_name=_('Tax deduced'))
    fees = models.ManyToManyField(Fees)
    user = models.ForeignKey(User)

    def __unicode__(self):
        return u'%s' %self.description
    
    class Meta:
        verbose_name_plural = "Items"
        verbose_name  = "Item" 
        
class ItemsAdmin(admin.ModelAdmin):
    list_display = ('description', 'user')
    list_filter = ['description', 'user']
    search_fields = ['description', 'user']

admin.site.register(Items, ItemsAdmin)

class ItemsForm(ModelForm):
    class Meta:
        model = Items
        fields = ['unitprice','unitmeasurement', 'description',]

