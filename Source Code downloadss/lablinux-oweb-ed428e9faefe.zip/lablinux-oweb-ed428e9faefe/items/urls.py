# -*- coding: iso-8859-1 -*-
from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('items.views' ,
    url(r'^(?P<tipo>\.pdf|\.pdf2|\.pdf3|\.pdf4)?/$'    , 'index'  , name='items-index'),
    url(r'^/update/(?P<id>\d+)/$'            , 'update' , name='items-update'),
    url(r'^/new/$'                          , 'new'    , name='items-new'),
    url(r'^/delete/(?P<id>\d+)/$'            , 'delete' , name='items-delete'),
    #url(r'^/ajax/(?P<id>\d+)/(?P<idx>\d+)/(?P<qta>\d+)/$'  , 'ajax'   , name='items-ajax'),
    url(r'^/ajax/(?P<id>\d+)/(?P<idx>\d+)/(?P<qta>\d+\.*\d*)/$'  , 'ajax'   , name='items-ajax'),
    #url(r'^/ajax_list/(?P<idx>\d+)/(?P<id>\d+)/(?P<extdesct>[a-zA-Z0-9_ ]+)/(?P<qta>\d+)/$'  , 'ajax_list' , name='items-ajax-list'),
    url(r'^/ajax_list/(?P<idx>\d+)/(?P<id>\d+)/(?P<extdesct>[a-zA-Z0-9_()\[\]\.\,<>\!\@\# ]+)/(?P<qta>\d+\.*\d*)/$'  , 'ajax_list' , name='items-ajax-list'),
    #url(r'^/ajax_list/(?P<idx>\d+)/(?P<id>\d+)/(?P<qta>\d+)/$'  , 'ajax_list' , name='items-ajax-list'),
    url(r'^/ajax_list/(?P<idx>\d+)/(?P<id>\d+)/(?P<qta>\d+\.*\d*)/$'  , 'ajax_list' , name='items-ajax-list'),
    url(r'^/pippo/$'                          , 'pippo'    , name='items-pippo'),
) 
