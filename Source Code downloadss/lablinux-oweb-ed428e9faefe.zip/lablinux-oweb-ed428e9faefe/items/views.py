from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.template import RequestContext, Context
from django.template.loader import get_template
from django.core.urlresolvers  import reverse
from django.contrib.auth.decorators import login_required
from items.models import Items, ItemsForm
from fees.models import Fees
from django.contrib.auth.models import User
from django import forms

def get_choicesItems(userid=None):
    items = Items.objects.filter(user=userid)
    return [(item.id,item.description[0:30]) for item in items]

class formItem(forms.Form):
    def __init__(self, uid=None, nameField=None, *args, **kwargs):
        super(formItem, self).__init__(*args, **kwargs)
        self.fields['Item'] = forms.ChoiceField(choices=get_choicesItems(uid))
        self.fields['Item_descr'] = forms.CharField(label="additiona info")

import ho.pisa 
import cStringIO
#from reportlab.pdfgen import canvas

import utility

@login_required
def ajax_list(request, idx=0, id=0, extdesct='' ,qta=0):
    form = formItem(uid=request.user.id) # An unbound for
    #if id > 0:
    #    item = Items.objects.get(pk=id)
    #else:
    item={'id':0}
    if extdesct:
        extdesct = extdesct.strip()
    return render_to_response('items/ajax_list.html' , 
                             {'form' : form,
                              'item' : item,
                              'idx' : idx, 
                              'id' : int(id), 
                              'extdesct' : extdesct, 
                              'qta' : qta ,} ,
                               context_instance=RequestContext(request))

@login_required
def ajax(request, id=None, idx=None, qta=None):
    item = Items.objects.get(id=id)
    return render_to_response('items/ajax.html' , 
                             {'item' : item,
                             'idx' : idx,
                             'qta' : qta, } ,
                              context_instance=RequestContext(request))

@login_required
def index(request, tipo = None):

    items = Items.objects.filter(user=request.user.id)

    #response = render_to_response('items/index.html' , RequestContext(request, {'items' : items, }) )
    response = render_to_response('items/index.html', {'items' : items, }, context_instance=RequestContext(request))
    
    if tipo == '.pdf2':
        file_pdf = cStringIO.StringIO()
        ho.pisa.CreatePDF(unicode(response, encoding='utf-8'), file_pdf)
        return HttpResponse(file_pdf.getvalue(), content_type = "application/pdf")
     
    if tipo == '.pdf':
        return render_to_response('items/indexpdf.html' , RequestContext(request, {'items' : items, }) )
        #return render_to_pdf('items/indexpdf.html',{'pagesize':'A4', \
        #                                          'title':'Items',  \
        #                                          'items' : items,})          
    if tipo == '.pdf3':
        response = HttpResponse(mimetype='application/pdf')
        response['Content-Disposition'] = 'attachment; filename=somefilename.pdf'

        # Create the PDF object, using the response object as its "file."
        p = canvas.Canvas(response)

        # Draw things on the PDF. Here's where the PDF generation happens.
        # See the ReportLab documentation for the full list of functionality.
        p.drawString(100, 100, "Hello world.")

        # Close the PDF object cleanly, and we're done.
        p.showPage()
        p.save()
        return response

    if tipo == '.pdf4':
        # Create the HttpResponse object with the appropriate PDF headers.
        response = HttpResponse(mimetype='application/pdf')
        response['Content-Disposition'] = 'attachment; filename=somefilename.pdf'

        buffer = cStringIO.StringIO()

        # Create the PDF object, using the StringIO object as its "file."
        p = canvas.Canvas(buffer)
        #, \
        #                  #pagesize = A4, \
        #                  #pagesize = eval('landscape(A4)'), \
        #                  bottomup = 0)

        # Draw things on the PDF. Here's where the PDF generation happens.
        # See the ReportLab documentation for the full list of functionality.
        p.drawString(100, 100, "Hello world 100,100.")
        p.drawString(300, 100, "Hello world 300,100.")
        p.drawString(400, 100, "Hello world 400.100.")
        p.drawString(400, 500, "Hello world 400.500.")
        # Close the PDF object cleanly.

        p.showPage()
        p.save()

        # Get the value of the StringIO buffer and write it to the response.
        pdf = buffer.getvalue()
        buffer.close()
        response.write(pdf)
        return response

    
    return response
    

@login_required      
def update(request, id=None):
    item = get_object_or_404(Items, id=id, user=request.user.id)
    form = ItemsForm(request.POST or None ,instance=item)
    if request.method == 'POST':
        if form.is_valid():
            obj_model_form = form.save(commit=False)
            obj_model_form.user = User.objects.get(id=request.user.id)
            obj_model_form.save()
        
            for fee in item.fees.values(): # delete the fee connected to item
                item.fees.remove(fee['id'])
                
            for id in range(1, int(request.REQUEST['numberfee']) + 1):
                try:
                    fee = Fees.objects.get(id = int(request.REQUEST['Fee_%s' %id]) )
                    obj_model_form.fees.add(fee)
                    obj_model_form.save()
                except KeyError:
                    None
                    
            return HttpResponseRedirect(reverse ('items-index'))

    return render_to_response('items/update.html' , 
                              {'form': form,
                               'item': item, } ,
                               context_instance=RequestContext(request))
    #return utility.update(Items, ItemsForm, request, id, 'items-index', 'crud/update.html')

#@login_required  
#def new(request):
#    return utility.new(ItemsForm, request, 'items-index', 'crud/new.html')

@login_required
def new(request):
    form = ItemsForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            obj_model_form = form.save(commit=False)
            obj_model_form.user = User.objects.get(id=request.user.id)
            obj_model_form.save()
            
            for id in range(1, int(request.REQUEST['numberfee']) + 1):
                try:
                    fee = Fees.objects.get(id = int(request.REQUEST['Fee_%s' %id]) )
                    obj_model_form.fees.add(fee)
                    obj_model_form.save()
                except KeyError:
                    None
            
            return HttpResponseRedirect(reverse ('items-index'))

    return render_to_response( 'items/new.html' , 
                              {'form' : form,
                               'title' : 'New Item', } ,
                               context_instance=RequestContext(request))

@login_required  
def delete(request, id=None):
    return utility.delete(Items, request, id, 'items-index')
    

def render_to_pdf(template_src, context_dict):
    template = get_template(template_src)
    context = Context(context_dict)
    html  = template.render(context)
    result = cStringIO.StringIO()
    pdf = ho.pisa.pisaDocument(cStringIO.StringIO(html.encode("utf-8")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), mimetype='application/pdf')
    return HttpResponse('We had some errors<pre>%s</pre>' % cgi.escape(html))
    

def pippo(request):
    return HttpResponse("ciccio;pasticcio", mimetype='application/csv')