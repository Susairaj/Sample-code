from django.contrib import auth

#from django.contrib.auth.models import User
from profiles.models  import ProfileUser

class ProfilingUser(object):
    def process_request(self, request):
        from django.contrib.auth import get_user
        u = get_user(request)
        p = ProfileUser.objects.filter(user=u)
        if not(p):
            ProfileUser(user=u, language='en').save()
        return None


