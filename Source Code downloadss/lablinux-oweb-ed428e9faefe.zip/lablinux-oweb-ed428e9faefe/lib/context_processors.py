def url( request ):
    return { 'path' : request.path.split('/')[1] } 