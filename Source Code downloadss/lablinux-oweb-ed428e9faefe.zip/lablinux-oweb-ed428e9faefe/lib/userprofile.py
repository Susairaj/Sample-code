from django.contrib import auth

from profiles.models  import ProfileUser

class ProfilingUser(object):
    def process_request(self, request):
        from django.contrib.auth import get_user
        try:
            u = get_user(request)
            p = ProfileUser.objects.filter(user=u)
            if not(p):
                p = ProfileUser(user=u, language='en')
                p.save()
            lang_code = p.language
            request.session['django_language'] = lang_code
        except:
            None
        return None

        

    
