from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.forms import ModelForm
from django.utils.translation import ugettext as _

class Payterms(models.Model):
    description1   = models.CharField(max_length=120, verbose_name=_("line 1"))
    description2   = models.CharField(null=True, blank=True, max_length=120, verbose_name=_("line 2"))
    description3   = models.CharField(null=True, blank=True, max_length=120, verbose_name=_("line 3"))
    user           = models.ForeignKey(User)
    
    def __unicode__(self):
        return u"%s, %s, %s" %(self.description1, self.description2,  self.description3 )
        
    class Meta:
        verbose_name_plural = "Payment terms"
        verbose_name  = "Payment term" 


class PaytermsAdmin(admin.ModelAdmin):
    list_display = ('description1', 'description2', 'description3')
    list_filter = ['description1', 'description2', 'description3']
    search_fields = ['description1', 'description2', 'description3']

admin.site.register(Payterms, PaytermsAdmin)


class PaytermsForm(ModelForm):
    class Meta:
        model = Payterms
        fields = ['description1', \
                  'description2', \
                  'description3' ]
        


