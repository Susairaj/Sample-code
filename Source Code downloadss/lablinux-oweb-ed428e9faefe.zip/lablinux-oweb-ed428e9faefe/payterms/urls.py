from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('payterms.views' ,
    url(r'^/$'                              , 'index'  , name='payterms-index'),
    url(r'^/update/(?P<id>\d+)/$'            , 'update' , name='payterms-update'),
    url(r'^/new/$'                          , 'new'    , name='payterms-new'),
    url(r'^/delete/(?P<id>\d+)/$'            , 'delete' , name='payterms-delete'),
    url(r'^/ajax/(?P<id>\d+)/$'              , 'ajax'   , name='payterms-ajax'),
)
