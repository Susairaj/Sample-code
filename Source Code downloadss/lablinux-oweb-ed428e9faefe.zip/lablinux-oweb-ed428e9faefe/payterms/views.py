from django.shortcuts               import render_to_response
from django.template                import RequestContext
from django.contrib.auth.decorators import login_required
from payterms.models                import Payterms, PaytermsForm
from django.contrib.auth.models     import User
import utility


@login_required
def ajax(request, id=None):
    payterm = Payterms.objects.get(id=id)
    return render_to_response('payterms/ajax.html' , 
                             {'payterm'    : payterm,} ,
                               context_instance=RequestContext(request))


@login_required
def index(request):
    payterms = Payterms.objects.filter(user=request.user.id)
    return render_to_response('payterms/index.html' , 
                             {'payterms'    : payterms, } ,
                               context_instance=RequestContext(request))
@login_required
def update(request, id=None):
    return utility.update(Payterms, PaytermsForm, request, id, 'payterms-index', 'crud/update.html')

@login_requireddef new(request):
    return utility.new(PaytermsForm, request, 'payterms-index', 'crud/new.html')

@login_required
def delete(request, id=None):
    return utility.delete(Payterms, request, id, 'payterms-index')
