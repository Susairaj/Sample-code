from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.forms  import ModelForm

class ProfileUser(models.Model):
    def __unicode__(self):
        return "%s's Profile" % self.user.username
    user = models.ForeignKey(User, unique=True)
    language = models.CharField(max_length = 2)



#class ProifileUserAdmin(admin.ModelAdmin):
#    list_display = ('language',)
#    list_filter = ['language', ]
#    search_fields = ['language', ]
#
#admin.site.register(ProfileUser, ProifileUserAdmin)

#class ProfileUserForm(ModelForm):
#    class Meta:
#        model = ProfileUser
#        fields = ['lenguage',]