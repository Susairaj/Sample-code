from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()


urlpatterns = patterns('profiles.views' ,
    url(r'^/$'           , 'index'  , name='profiles-index'),
    url(r'^/updatepsw/$'   , 'updatepsw' , name='profiles-updatepsw'),
    url(r'^/updatelang/$'   , 'updatelang' , name='profiles-updatelang'),
)
