from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.template import RequestContext
from django.core.urlresolvers  import reverse
from django.contrib.auth.decorators import login_required
from django import forms
from django.conf import settings
from django.contrib.auth.models import User
from django.utils.translation import ugettext as _

#from django.views.decorators.cache import never_cache
#from django.contrib.auth.forms import AuthenticationForm

from settings import MEDIA_ROOT

from profiles.models  import ProfileUser #, ProfileUserForm


class PasswordForm(forms.Form):
    newpassword = forms.CharField(max_length=100)
    confirmpassword = forms.CharField(max_length=100)
    
    def clean(self):
        cleaned_data = self.cleaned_data
        newpsw = cleaned_data.get("newpassword")
        confirmpsw = cleaned_data.get("confirmpassword")
        if newpsw != confirmpsw :
            raise forms.ValidationError(_('Check and confirm password'))
        if len(newpsw) < 8:
            raise forms.ValidationError(_('Password is too short, min 8 charater'))
        
        return cleaned_data


#@never_cache
#def login(request):
#    if request.method == 'POST':
#        form = authentication_form(data=request.POST)
#        user = form.cleaned_data
#        if form.is_valid():
#            user = authenticate(username=user['user'], password=user['password'])
#            if user is None:
#                raise forms.ValidationError(_("Please enter a correct username and password. Note that both fields are case-sensitive."))
#            elif not self.user_cache.is_active:
#                raise forms.ValidationError(_("This account is inactive."))
#    else:
#        form = authentication_form(request)
#        return render_to_response('profiles/login.html', 
#                {'form': form, }, 
#                context_instance=RequestContext(request))



@login_required
def index(request):
    user = User.objects.get(pk=request.user.id)         
    passwdform = PasswordForm()
    return render_to_response('profiles/index.html' , 
                             {'user'    : user,
                              'passwdform' : passwdform,} ,
                           context_instance=RequestContext(request))
@login_required                           
def updatepsw(request):
    form = PasswordForm(request.POST or None)
    user = User.objects.get(pk=request.user.id)         
    if request.method == 'POST':
        if form.is_valid():
            paswd = form.cleaned_data

            user.set_password(paswd['newpassword'])
            user.save()

    return HttpResponseRedirect(reverse ('profiles-index'))

@login_required                           
def updatelang(request):
    if request.method == 'POST':
        if 'language' in request.REQUEST:
            lang_code = request.POST.get('language')
            user = User.objects.get(pk=request.user.id)         
            try:
                profile = ProfileUser.objects.get(user =user)
            except:
                profile = ProfileUser()
                profile.user = user
            profile.language = lang_code  
            profile.save()
            request.session['django_language'] = lang_code
                        

    return HttpResponseRedirect(reverse ('profiles-index'))

