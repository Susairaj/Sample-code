from invoices.models  import InvoiceHeaders, InvoiceBodies, InvoiceHeadersModel #invoicehesForm, , InvoiceBodiesForm
from contacts.models import Contacts
from payterms.models import Payterms
from items.models import Items
from fees.models import Fees

ih = InvoiceHeaders.objects.get(pk=34)
ib = ih.invoicebodies_set.all()
ib[0]
ibf = ib[0].invoicebodiesfees_set.all()
ibf[0]

from items.models import Items, ItemsForm
from fees.models import Fees
item = Items.objects.get(pk=5)
item.fees.values




id = 7
invoiceheader = InvoiceHeaders.objects.get(pk=id)
bodies = []    
gros = 0
net = 0
tax = 0

for body in invoiceheader.invoicebodies_set.values():
    body['tax'] = 0
    body['net'] = 0
    body['gros'] = body['unitprice'] * body['quantity']
    for fees in InvoiceBodies.objects.get(pk=body['id']).invoicebodiesfees_set.all():
        body['tax'] += ( body['gros'] / 100 ) * fees.percentage
    gros += body['gros'] 
    tax += body['tax']
    body['net'] = body['gros'] + body['tax']
    bodies.append(body)
net = gros + tax
bodies




id=2
invoiceheader = InvoiceHeaders.objects.get(pk=id)
bodies = []    
gros = 0
net = 0
taxtotal = 0

for body in invoiceheader.invoicebodies_set.values():
    body['tax'] = []
    body['net'] = 0
    tax = 0
    body['gros'] = body['unitprice'] * body['quantity']
    for fees in InvoiceBodies.objects.get(pk=body['id']).invoicebodiesfees_set.all():
        body['tax'].append({'name':fees.description, 'value':( body['gros'] / 100 ) * fees.percentage} ) 
        tax += ( body['gros'] / 100 ) * fees.percentage
    gros += body['gros'] 
    body['net'] = body['gros'] + tax
    taxtotal += tax
    bodies.append(body)

net = gros + taxtotal