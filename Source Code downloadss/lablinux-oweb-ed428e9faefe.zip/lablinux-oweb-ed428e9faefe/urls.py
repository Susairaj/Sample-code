from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^oweb/', include('oweb.foo.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs'
    # to INSTALLED_APPS to enable admin documentation:
    (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    #(r'^admin/', include(admin.site.urls)),
    (r'^admin/(.*)', admin.site.root),

    (r'^i18n/',  include('django.conf.urls.i18n') ),

    (r'accounts/logout/$', 'django.contrib.auth.views.logout'),

    (r'^accounts/login/$', 'django.contrib.auth.views.login'),

    #(r'^personaldata', include('personaldata.urls')),
    (r'^contacts', include('contacts.urls')),
    (r'^items', include('items.urls')),
    (r'^invoices', include('invoices.urls')),
    (r'^payterms', include('payterms.urls')),
    (r'^fees', include('fees.urls')),
    (r'^home', include('home.urls')),
    (r'^profiles', include('profiles.urls')),
    url(r'^logout/$'    , 'views.logout_view'  , name='logout-view'),

)

import os
from django.conf import settings
if settings.DEBUG:
    urlpatterns += patterns('',
        (r'^media/(.*)$', 'django.views.static.serve', {'document_root': os.path.join(settings.PROJECT_PATH, 'media'), 'show_indexes': True}),
    )

urlpatterns += patterns('django.views.generic.simple',
    (r'^$',  'redirect_to', {'url' : 'invoices'} ),
)
