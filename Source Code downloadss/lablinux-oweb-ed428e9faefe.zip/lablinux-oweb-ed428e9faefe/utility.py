from django.http                    import HttpResponseRedirect, HttpResponse
from django.shortcuts               import render_to_response, get_object_or_404
from django.template                import RequestContext
from django.contrib.auth.models     import User
from django.core.urlresolvers       import reverse


def update(obj_model=None, obj_form=None, request=None, id=None, pageOk=None, templateForm=None, title=None):
    obj_instance = get_object_or_404(obj_model, id=id, user=request.user.id)
    form = obj_form(request.POST or None ,instance=obj_instance)
    if form.is_valid():
       form.save()
       return HttpResponseRedirect(reverse (pageOk))

    return render_to_response(templateForm , 
                              {'form': form,
                              'title' : title,} ,
                               context_instance=RequestContext(request))

def new(obj_form=None, request=None, pageOk=None, templateForm=None, title=None):
    form = obj_form(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            obj_model_form = form.save(commit=False)
            obj_model_form.user = User.objects.get(id=request.user.id)
            obj_model_form.save()
            return HttpResponseRedirect(reverse (pageOk))

    return render_to_response( templateForm , 
                              {'form' : form,
                               'title' : title, } ,
                               context_instance=RequestContext(request))

def delete(obj_model=None, request=None, id=None, pageOk=None):
    if request.method == 'GET':
        obj_to_delete = get_object_or_404(obj_model, id=id, user=request.user.id)
        obj_to_delete.delete()
    
    return HttpResponseRedirect(reverse (pageOk))

def date_ita(dt_to_translate = None):
    return "%02d/%02d/%04d" %(dt_to_translate.day, dt_to_translate.month, dt_to_translate.year)