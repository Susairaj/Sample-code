Base module for the Odoo [Web Client tutorial](//github.com/odoo/odoo/blob/8.0/doc/howtos/web.rst)

