# shade
My Django social network

**Requirements:**  
[django_markdown](https://github.com/klen/django_markdown)
