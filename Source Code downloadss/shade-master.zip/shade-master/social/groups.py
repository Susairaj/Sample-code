class GroupUpdates:
	#name = ""
	updates = []

	#def __str__(self):
	#	return {name: updates}
