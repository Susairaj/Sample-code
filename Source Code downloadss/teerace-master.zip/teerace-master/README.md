![Teerace](http://code.ksocha.com/teerace/images/logo.png)

Basic description
-----------------
Teerace is a project gathering results from a network of trusted Teeworlds Race-mod servers.
Modified server is also a part of this project, it is able to communicate with webapp through its API.

This repository covers web application part only.
The [teerace-ready gameserver](https://github.com/SushiTee/teeworlds/tree/teerace) is developed by SushiTee and Redix.

Network graph
-----
![network graph](https://github.com/chaosk/teerace/raw/master/teerace/media/images/network_graph.png)

License
-------
Licensed under New BSD License.

This project is heavily modeled on [warsow racenet](http://warsow-race.net/). Kudos!