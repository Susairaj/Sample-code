#3MIT

3MIT is a technique for productivity where you write down the three most important things you have to do today in the 
beginning of your day, and you keep it in front of you all day until you complete them. It allows you set your priorties 
and keep them straight throughtout the day.

This application is a jump into 3MIT using Polymer.

