core-popup-menu
===============

owner: [@morethanreal](http://github.com/morethanreal)

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-popup-menu) for more information.
