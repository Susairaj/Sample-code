#!/bin/bash
    exec ./manage.py runserver --settings=goodcode_nv.local_settings
