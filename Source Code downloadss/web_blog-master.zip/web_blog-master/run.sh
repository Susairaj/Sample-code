#!/bin/bash
    source /home/fireant/goodcode_nv/vcode/bin/activate
    exec ./manage.py runserver 212.110.191.178:8000
