# findPath 1.1
# diogo dubiella
# www.dubiella.com

import nuke
import fnmatch
import os


def findPath():
	# lista as subPastas da pasta selecionada
	basePath = nuke.getFilename('Select Dir', " ", type = 'open')

	if basePath != None:
		path = os.path.join(basePath)
		for r,d,f in os.walk(path):
			subpath = r
		MenssagemFinal = ""
		#ve todos os read node com erro e pega o nome do arquivo.
		for a in nuke.allNodes():
			if a.Class()=='Read':
				if a.error() == True:
					oldpath = a['file'].value()
					oldfinemae = os.path.basename(oldpath)
					#dados para procurar
					fileExt = oldfinemae[-3:]
					fileName = oldfinemae[:-4]

					if fileName.find("%d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%d","*")
					if fileName.find("%02d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%02d","*")
					if fileName.find("%03d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%03d","*")
					if fileName.find("%04d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%04d","*")
					if fileName.find("%05d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%05d","*")
					if fileName.find("%06d") != -1:
						newfindname = fileName.replace("%d","*") and fileName.replace("%06d","*")
					findFile = newfindname + "." + fileExt

					## Procura o aquivo nas subpastas
					path = os.path.join(basePath)
					for r,d,f in os.walk(path):
						subpath = r
						for file in os.listdir(subpath):
							if fnmatch.fnmatch(file, findFile):
								reformatPath = subpath.replace("\\","/")
								a['file'].setValue(reformatPath +'/'+ oldfinemae)
								
					if a.error() == False:
						MenssagemFinal = a.name() + " - " + oldfinemae + " - " + " Found Successfully!" + "\n" + MenssagemFinal
					else:
						MenssagemFinal = a.name() + " - " + oldfinemae + " - " + " Not Found!" + "\n" + MenssagemFinal
				else:
					if MenssagemFinal == "":
						MenssagemFinal = "You don't have any readNode with error!."
	else:
		MenssagemFinal = "No folder was selected!"
	nuke.message(MenssagemFinal)