import findPath

# findPath
m = menubar.addMenu("&Edit")
m.addCommand("-", "", "")
m.addCommand("findPath", "findPath.findPath()" , icon='findPath.png')