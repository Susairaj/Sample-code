Contributing to Open Mining
===========================

As an open source project, Open Mining welcomes contributions of many forms.

Examples of contributions include:

* Code patches
* Documentation improvements
* Bug reports and patch reviews

Pull requests are welcome! `Open an issue`__ to suggest changes.

__ https://github.com/avelino/mining/issues
