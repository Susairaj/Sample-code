# Why Open Mining?

**Open Mining** is software for creating OLAP (online analytical processing) cubes (multi-dimensional) using Numpy, 
Scipy and Pandas for data management and flexibility in processing dynamical filters. Open-source provider of 
reporting, analysis, dashboard, data mining and workflow capabilities.
