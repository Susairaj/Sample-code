# -*- coding: utf-8 -*-
class DataManager(object):
    def __init__(self, ws):
        self.ws = ws
        self.data = []
